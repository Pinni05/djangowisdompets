from django.apps import AppConfig


class AdoptionsConfig(AppConfig):
    name = 'adoptions'
